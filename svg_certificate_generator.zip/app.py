
from flask import Flask, request, send_file, render_template_string, send_from_directory
import cairosvg
import os

os.makedirs('./static/generated_certificates', exist_ok=True)

app = Flask(__name__, static_folder="static")

TEMPLATE_FILE = './static/template.svg'
FILLED_SVG = './static/filled_certificate.svg'
PDF_FILE = './static/generated_certificates/certificate.pdf'

@app.route('/')
def home():
    with open('static/editor.html', 'r', encoding='utf-8') as f:
        html = f.read()
    return render_template_string(html)

@app.route('/form')
def form_page():
    return send_from_directory('static', 'form.html')

@app.route('/upload-template', methods=['POST'])
def upload_template():
    svg_data = request.data.decode('utf-8')
    with open(TEMPLATE_FILE, 'w', encoding='utf-8') as f:
        f.write(svg_data)
    return {'status': 'Template saved'}

@app.route('/generate-certificate', methods=['POST'])
def generate_certificate():
    data = request.json if request.is_json else request.form.to_dict()
    if not os.path.exists(TEMPLATE_FILE):
        return {"error": "Template file not found."}, 404

    with open(TEMPLATE_FILE, 'r', encoding='utf-8') as file:
        svg_content = file.read()
    for key, value in data.items():
        svg_content = svg_content.replace(f"{{{{{key}}}}}", value)
    with open(FILLED_SVG, 'w', encoding='utf-8') as file:
        file.write(svg_content)

    cairosvg.svg2pdf(url=FILLED_SVG, write_to=PDF_FILE)
    return send_file(PDF_FILE, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
